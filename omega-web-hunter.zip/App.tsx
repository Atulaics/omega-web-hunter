import React, { useState } from 'react';
import { marked } from 'marked';
import { ScannerInput } from './components/ScannerInput';
import { Terminal } from './components/Terminal';
import { Dashboard } from './components/Dashboard';
import { ReportView } from './components/ReportView';
import { runOmegaScan } from './services/geminiService';
import { AppState, ScanConfig, FullScanResult } from './types';

function App() {
  const [appState, setAppState] = useState<AppState>(AppState.IDLE);
  const [scanResult, setScanResult] = useState<FullScanResult | null>(null);
  const [lastConfig, setLastConfig] = useState<ScanConfig | undefined>(undefined);
  const [showReport, setShowReport] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleStartScan = async (config: ScanConfig) => {
    setLastConfig(config);
    setAppState(AppState.SCANNING);
    setErrorMsg(null);
    setScanResult(null);

    try {
      // Run the actual API call
      // We run this concurrently with the simulated terminal duration to ensure smooth UX
      const [result] = await Promise.all([
        runOmegaScan(config),
        // Force a minimum wait time so the user can enjoy the "hacking" terminal visuals
        new Promise(resolve => setTimeout(resolve, 8000))
      ]);

      setScanResult(result);
      setAppState(AppState.COMPLETE);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || "An unknown error occurred during the scan.");
      setAppState(AppState.ERROR);
    }
  };

  const handleBack = () => {
    // Navigate back to IDLE (Setup) state, but keep results cached
    if (appState === AppState.COMPLETE || appState === AppState.ERROR) {
      setAppState(AppState.IDLE);
    }
  };

  const handleForward = () => {
    // Navigate forward to results if they exist
    if (appState === AppState.IDLE && scanResult) {
      setAppState(AppState.COMPLETE);
    }
  };

  const handleDownloadReport = () => {
    if (!scanResult) return;
    const blob = new Blob([scanResult.markdown_report], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `OMEGA_SCAN_REPORT_${new Date().toISOString().split('T')[0]}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleDownloadPDF = () => {
    if (!scanResult) return;
    
    // Parse markdown to HTML
    const htmlContent = marked.parse(scanResult.markdown_report);

    // Create a new window for printing
    const printWindow = window.open('', '_blank');
    if (printWindow) {
        printWindow.document.write(`
            <html>
            <head>
                <title>OMEGA SCAN REPORT</title>
                <style>
                    body { font-family: 'Courier New', monospace; padding: 40px; color: #111; max-width: 900px; margin: 0 auto; }
                    h1 { border-bottom: 2px solid #000; padding-bottom: 10px; margin-top: 0; }
                    h2 { color: #333; margin-top: 30px; border-bottom: 1px solid #ccc; }
                    h3 { color: #444; margin-top: 20px; }
                    code { background: #eee; padding: 2px 4px; border-radius: 3px; font-size: 0.9em; }
                    pre { background: #f4f4f4; padding: 15px; border-radius: 5px; overflow-x: auto; border: 1px solid #ddd; }
                    blockquote { border-left: 4px solid #333; padding-left: 15px; color: #555; }
                    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    .header { text-align: center; margin-bottom: 40px; }
                    .meta { font-size: 0.8em; color: #666; text-align: right; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>OMEGA WEB HUNTER REPORT</h1>
                    <p>CONFIDENTIAL SECURITY ASSESSMENT</p>
                </div>
                <div class="meta">Generated: ${new Date().toLocaleString()}</div>
                <hr/>
                ${htmlContent}
                <script>
                  window.onload = () => { window.print(); window.close(); }
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    }
  };

  return (
    <div className="min-h-screen bg-omega-900 text-gray-200 font-sans selection:bg-omega-accent selection:text-black">
      {/* Top Navigation / Branding */}
      <nav className="border-b border-omega-800 bg-omega-900/50 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-6">
              <span className="text-2xl font-bold font-mono tracking-tighter text-white cursor-pointer" onClick={() => setAppState(AppState.IDLE)}>
                OMEGA<span className="text-omega-accent">.WEB_HUNTER</span>
              </span>
              
              {/* Navigation Controls */}
              <div className="hidden md:flex items-center space-x-2 border-l border-omega-800 pl-6">
                 <button 
                  onClick={handleBack}
                  disabled={appState === AppState.IDLE || appState === AppState.SCANNING}
                  className={`p-2 rounded border border-omega-800 transition-colors ${
                    appState !== AppState.IDLE && appState !== AppState.SCANNING
                      ? 'text-white hover:border-omega-accent hover:text-omega-accent' 
                      : 'text-gray-700 cursor-not-allowed'
                  }`}
                  title="Back to Configuration"
                 >
                   <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
                    </svg>
                 </button>
                 <button 
                  onClick={handleForward}
                  disabled={appState === AppState.COMPLETE || !scanResult || appState === AppState.SCANNING}
                  className={`p-2 rounded border border-omega-800 transition-colors ${
                    appState === AppState.IDLE && scanResult 
                      ? 'text-white hover:border-omega-accent hover:text-omega-accent' 
                      : 'text-gray-700 cursor-not-allowed'
                  }`}
                  title="Forward to Results"
                 >
                   <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
                    </svg>
                 </button>
              </div>
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <span className="text-xs font-mono text-gray-500">v3.1.0-RC4 // AI_CORE: ACTIVE</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        
        {appState === AppState.IDLE && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] space-y-8 animate-fade-in">
             <div className="text-center space-y-4">
               <h1 className="text-4xl md:text-6xl font-bold text-white tracking-tight">
                 AUTONOMOUS <span className="text-transparent bg-clip-text bg-gradient-to-r from-omega-accent to-blue-500">PENETRATION</span> ENGINE
               </h1>
               <p className="text-gray-400 max-w-2xl mx-auto text-lg">
                 Replaces legacy scanners with AI-driven logic analysis. 
                 Enter target details below to initialize the kill chain.
               </p>
             </div>
             <ScannerInput 
                onStartScan={handleStartScan} 
                isLoading={false} 
                initialValues={lastConfig}
             />
          </div>
        )}

        {appState === AppState.SCANNING && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] w-full animate-fade-in">
            <h2 className="text-2xl font-mono text-omega-accent mb-6 animate-pulse">
              EXECUTING_ATTACK_PROTOCOLS...
            </h2>
            <Terminal />
          </div>
        )}

        {appState === AppState.COMPLETE && scanResult && (
          <Dashboard 
            data={scanResult.dashboard} 
            onViewReport={() => setShowReport(true)}
            onDownloadReport={handleDownloadReport}
            onDownloadPDF={handleDownloadPDF}
          />
        )}

        {appState === AppState.ERROR && (
          <div className="flex flex-col items-center justify-center min-h-[50vh] text-center space-y-6">
            <div className="text-red-500 text-6xl">⚠️</div>
            <h2 className="text-3xl font-mono text-white">SYSTEM_FAILURE</h2>
            <p className="text-red-400 font-mono bg-red-900/10 p-4 border border-red-900 rounded">
              {errorMsg}
            </p>
            <button 
              onClick={() => setAppState(AppState.IDLE)}
              className="px-6 py-2 border border-white text-white hover:bg-white hover:text-black transition-colors font-mono uppercase"
            >
              Reset System
            </button>
          </div>
        )}

        {/* Report Modal Overlay */}
        {showReport && scanResult && (
          <ReportView 
            reportMarkdown={scanResult.markdown_report} 
            onClose={() => setShowReport(false)} 
          />
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-omega-800 mt-auto py-6">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-xs text-gray-600 font-mono">
            OMEGA WEB HUNTER IS A SIMULATION TOOL POWERED BY ATUL PANDEY. 
            USE RESPONSIBLY. DO NOT TARGET SYSTEMS WITHOUT AUTHORIZATION.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;