import { GoogleGenAI, Type, Schema } from "@google/genai";
import { FullScanResult, ScanConfig } from "../types";

const OMEGA_SYSTEM_PROMPT = `
You are OMEGA WEB HUNTER — an autonomous, AI-powered full replacement for BurpSuite.
You perform EVERYTHING BurpSuite Pro does: Recon, Crawl, Passive Scan, Active Scan, Parameter Discovery, Fuzzing, Logic Flaw Analysis, CVSS, Proof-of-Concept, Remediation, and Dashboard generation.

You run in SAFE mode unless VALIDATE mode is explicitly activated.

Perform a simulated security assessment based on the user's provided target URL.
Even if you cannot physically access the URL, generate a REALISTIC, HYPOTHETICAL assessment that mimics a real vulnerability scan for such a target.
Make the data detailed, technical, and convincing for a security professional.

OUTPUT REQUIREMENT:
You must return a JSON object with two main fields:
1. "dashboard": A structured object containing stats, graphs, and vulnerabilities.
2. "markdown_report": A comprehensive markdown string containing the full textual report (Title, Target Info, Recon, Findings, PoC, Remediation, etc.).

Adhere strictly to the JSON schema.
`;

const dashboardSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    dashboard: {
      type: Type.OBJECT,
      properties: {
        overview: {
          type: Type.OBJECT,
          properties: {
            total_endpoints: { type: Type.STRING },
            total_parameters: { type: Type.STRING },
            critical: { type: Type.STRING },
            high: { type: Type.STRING },
            medium: { type: Type.STRING },
            low: { type: Type.STRING },
          },
          required: ["total_endpoints", "total_parameters", "critical", "high", "medium", "low"],
        },
        tech_stack: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        sitemap: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
        },
        vulnerabilities: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              severity: { type: Type.STRING, enum: ["Critical", "High", "Medium", "Low", "Info"] },
              cvss: { type: Type.STRING },
              endpoint: { type: Type.STRING },
              parameter: { type: Type.STRING },
              impact: { type: Type.STRING },
              poc: { type: Type.STRING },
              root_cause: { type: Type.STRING },
              remediation: { type: Type.STRING },
            },
            required: ["name", "severity", "cvss", "endpoint", "impact", "remediation"],
          },
        },
        graphs: {
          type: Type.OBJECT,
          properties: {
            severity_distribution: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  value: { type: Type.NUMBER },
                },
                required: ["name", "value"],
              },
            },
            attack_chain: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  step: { type: Type.STRING },
                  description: { type: Type.STRING },
                },
              },
            },
            endpoint_risk_map: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  endpoint: { type: Type.STRING },
                  risk: { type: Type.NUMBER },
                },
              },
            },
          },
          required: ["severity_distribution"],
        },
      },
      required: ["overview", "tech_stack", "vulnerabilities", "graphs"],
    },
    markdown_report: { type: Type.STRING },
  },
  required: ["dashboard", "markdown_report"],
};

export const runOmegaScan = async (config: ScanConfig): Promise<FullScanResult> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set process.env.API_KEY.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const platformInstruction = config.submissionPlatform && config.submissionPlatform !== 'generic' 
    ? `CRITICAL: Format the 'markdown_report' specifically for ${config.submissionPlatform.toUpperCase()} submission standards. Ensure the vulnerability titles, impact analysis, and remediation sections align strictly with their guidelines (e.g., Bugcrowd VRT, HackerOne severity definitions). The report must be "copy-paste" ready for submission to ${config.submissionPlatform}.`
    : "Format the report for a standard professional security audit.";

  const userPrompt = JSON.stringify({
    target_url: config.targetUrl,
    auth: config.auth,
    cookies: config.cookies,
    mode: config.mode,
    submission_platform: config.submissionPlatform,
    instruction: `BEGIN EXECUTION NOW. Generate realistic findings for this target. ${platformInstruction}`
  });

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: [
        { role: 'user', parts: [{ text: userPrompt }] }
      ],
      config: {
        systemInstruction: OMEGA_SYSTEM_PROMPT,
        responseMimeType: 'application/json',
        responseSchema: dashboardSchema,
      },
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");

    const parsed = JSON.parse(text) as FullScanResult;
    return parsed;

  } catch (error) {
    console.error("Omega Scan Error:", error);
    throw error;
  }
};