import React, { useEffect, useState, useRef } from 'react';

const LOG_MESSAGES = [
  "MODULE 1: RECON & CRAWL ENGINE STARTED...",
  "Resolving DNS...",
  "Mapping subdomains...",
  "Detecting WAF...",
  "Analyzing Tech Stack...",
  "MODULE 1 COMPLETE. 42 endpoints discovered.",
  "MODULE 2: PARAMETER INTELLIGENCE ENGINE STARTED...",
  "Identifying GET/POST vectors...",
  "Analyzing cookie entropy...",
  "MODULE 3: PASSIVE SCANNING STARTED...",
  "Checking security headers...",
  "Analyzing CORS policy...",
  "MODULE 4: ACTIVE SCANNER (SAFE MODE) STARTED...",
  "Testing SQL injection vectors...",
  "Testing XSS (Reflected/Stored)...",
  "Testing IDOR candidates...",
  "MODULE 5: AI LOGIC-FLAW DETECTOR STARTED...",
  "Analyzing workflow states...",
  "Checking payment logic...",
  "MODULE 6: PROOF OF CONCEPT GENERATION...",
  "Synthesizing exploit chains...",
  "MODULE 7: ROOT CAUSE ANALYSIS...",
  "Generating patch recommendations...",
  "MODULE 8: ATTACK PATH & CHAIN ENGINE...",
  "Calculating blast radius...",
  "MODULE 9: CVSS v3.1 SCORING...",
  "Finalizing risk assessment...",
  "GENERATING DASHBOARD JSON...",
];

export const Terminal: React.FC = () => {
  const [logs, setLogs] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let currentIndex = 0;
    const interval = setInterval(() => {
      if (currentIndex < LOG_MESSAGES.length) {
        setLogs(prev => [...prev, `[${new Date().toLocaleTimeString()}] ${LOG_MESSAGES[currentIndex]}`]);
        currentIndex++;
      } else {
        clearInterval(interval);
      }
    }, 400); // Speed of log appearance

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="w-full max-w-4xl mx-auto h-96 bg-black border border-omega-700 rounded-lg shadow-2xl overflow-hidden flex flex-col font-mono text-sm relative">
       {/* Scan line effect */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-omega-accent/5 to-transparent h-[10px] w-full animate-scan-line pointer-events-none opacity-50 z-10"></div>
      
      <div className="bg-omega-800 p-2 border-b border-omega-700 flex justify-between items-center">
        <span className="text-gray-400">omega-cli — ssh — 80x24</span>
        <div className="flex space-x-2">
           <div className="w-2 h-2 rounded-full bg-omega-accent animate-pulse"></div>
        </div>
      </div>
      <div 
        ref={scrollRef}
        className="flex-1 p-4 overflow-y-auto space-y-1 text-green-500 font-mono"
      >
        {logs.map((log, i) => (
          <div key={i} className="break-all opacity-90 hover:opacity-100 transition-opacity">
            <span className="text-omega-accent mr-2">{'>'}</span>
            {log}
          </div>
        ))}
        <div className="animate-pulse">_</div>
      </div>
    </div>
  );
};