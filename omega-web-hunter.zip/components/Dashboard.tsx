import React, { useState } from 'react';
import { DashboardData, Vulnerability } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { VulnerabilityModal } from './VulnerabilityModal';

interface DashboardProps {
  data: DashboardData;
  onViewReport: () => void;
  onDownloadReport: () => void;
  onDownloadPDF: () => void;
}

const SEVERITY_COLORS = {
  Critical: '#ff3333',
  High: '#ff9900',
  Medium: '#ffcc00',
  Low: '#00ccff',
  Info: '#999999',
};

export const Dashboard: React.FC<DashboardProps> = ({ data, onViewReport, onDownloadReport, onDownloadPDF }) => {
  const [selectedVuln, setSelectedVuln] = useState<Vulnerability | null>(null);

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 animate-fade-in pb-10">
      
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
        <h2 className="text-2xl font-mono font-bold text-white tracking-wider border-l-4 border-omega-accent pl-4">
          MISSION CONTROL
        </h2>
        <div className="flex flex-wrap gap-3">
          <button 
            onClick={onDownloadPDF}
            className="px-4 py-2 bg-omega-800 hover:bg-omega-700 text-white border border-omega-700 hover:border-white font-mono text-sm transition-all uppercase flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6.72 13.829c-.24.03-.48.062-.72.096m.72-.096a42.415 42.415 0 0 1 10.56 0m-10.56 0L6.34 18m10.94-4.171c.24.03.48.062.72.096m-.72-.096L17.66 18m0 0l.229 2.523a1.125 1.125 0 0 1-1.12 1.227H7.231c-.662 0-1.18-.568-1.12-1.227L6.34 18m11.318 0h1.091A2.25 2.25 0 0 0 21 15.75V9.456c0-1.081-.768-2.015-1.837-2.175a48.055 48.055 0 0 0-1.913-.247M6.34 18H5.25A2.25 2.25 0 0 1 3 15.75V9.456c0-1.081.768-2.015 1.837-2.175a48.041 48.041 0 0 1 1.913-.247m10.5 0a48.536 48.536 0 0 0-10.5 0m10.5 0V3.375c0-.621-.504-1.125-1.125-1.125h-8.25c-.621 0-1.125.504-1.125 1.125v3.659M18 10.5h.008v.008H18V10.5Zm-3 0h.008v.008H15V10.5Z" />
            </svg>
            PDF
          </button>
          <button 
            onClick={onDownloadReport}
            className="px-4 py-2 bg-omega-800 hover:bg-omega-700 text-white border border-omega-700 hover:border-white font-mono text-sm transition-all uppercase flex items-center gap-2"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4">
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 0 0 5.25 21h13.5A2.25 2.25 0 0 0 21 18.75V16.5M12 9.75v10.5m0 0L7.5 15.75M12 20.25l4.5-4.5M12 3v9" />
            </svg>
            MD
          </button>
          <button 
            onClick={onViewReport}
            className="px-6 py-2 bg-omega-700 hover:bg-omega-accent hover:text-black border border-omega-accent text-omega-accent font-mono text-sm transition-all uppercase"
          >
            View Full Report
          </button>
        </div>
      </div>

      {/* Top Stats Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'CRITICAL', value: data.overview.critical, color: 'text-red-500', border: 'border-red-500' },
          { label: 'HIGH', value: data.overview.high, color: 'text-orange-500', border: 'border-orange-500' },
          { label: 'ENDPOINTS', value: data.overview.total_endpoints, color: 'text-omega-accent', border: 'border-omega-accent' },
          { label: 'PARAMETERS', value: data.overview.total_parameters, color: 'text-blue-400', border: 'border-blue-400' },
        ].map((stat, i) => (
          <div key={i} className={`bg-omega-800 p-4 border-t-2 ${stat.border} shadow-lg`}>
            <p className="text-gray-500 font-mono text-xs uppercase">{stat.label}</p>
            <p className={`text-3xl font-bold font-mono ${stat.color}`}>{stat.value}</p>
          </div>
        ))}
      </div>

      {/* Main Grid: Charts & Sitemap */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Severity Chart */}
        <div className="bg-omega-800 p-6 rounded-sm border border-omega-700 shadow-xl col-span-1">
          <h3 className="text-gray-400 font-mono text-sm mb-4 border-b border-omega-700 pb-2">SEVERITY_DISTRIBUTION</h3>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.graphs.severity_distribution}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {data.graphs.severity_distribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={SEVERITY_COLORS[entry.name as keyof typeof SEVERITY_COLORS] || '#8884d8'} />
                  ))}
                </Pie>
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#111', borderColor: '#333' }}
                  itemStyle={{ color: '#fff', fontFamily: 'monospace' }}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Attack Chain / Risk Map (Simulated Bar for now) */}
         <div className="bg-omega-800 p-6 rounded-sm border border-omega-700 shadow-xl col-span-1 lg:col-span-2">
          <h3 className="text-gray-400 font-mono text-sm mb-4 border-b border-omega-700 pb-2">ENDPOINT_RISK_TOPOLOGY</h3>
           <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.graphs.endpoint_risk_map.slice(0, 8)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#222" />
                <XAxis dataKey="endpoint" stroke="#666" fontSize={10} tick={{fill: '#666'}} />
                <YAxis stroke="#666" />
                <RechartsTooltip 
                   cursor={{fill: 'rgba(255,255,255,0.05)'}}
                   contentStyle={{ backgroundColor: '#111', borderColor: '#333' }}
                   itemStyle={{ color: '#00ff41', fontFamily: 'monospace' }}
                />
                <Bar dataKey="risk" fill="#333" stroke="#00ff41" strokeWidth={1} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Tech Stack Pills */}
      <div className="bg-omega-800 p-4 border border-omega-700">
         <span className="text-gray-500 font-mono text-xs mr-4">DETECTED_TECH:</span>
         {data.tech_stack.map((tech, i) => (
           <span key={i} className="inline-block px-2 py-1 bg-omega-700 text-omega-accent text-xs font-mono mr-2 mb-2 border border-omega-600 rounded">
             {tech}
           </span>
         ))}
      </div>

      {/* Vulnerabilities Table */}
      <div className="bg-omega-800 border border-omega-700 shadow-xl overflow-hidden">
        <div className="p-4 border-b border-omega-700 bg-omega-900">
           <h3 className="text-white font-mono text-sm">DETECTED_VULNERABILITIES</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm font-mono">
            <thead className="bg-omega-900 text-gray-500 uppercase">
              <tr>
                <th className="px-6 py-3">Severity</th>
                <th className="px-6 py-3">Vulnerability</th>
                <th className="px-6 py-3">Endpoint</th>
                <th className="px-6 py-3">CVSS</th>
                <th className="px-6 py-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-omega-700">
              {data.vulnerabilities.map((vuln, idx) => (
                <tr key={idx} className="hover:bg-omega-700/50 transition-colors">
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 text-xs font-bold rounded ${
                      vuln.severity === 'Critical' ? 'bg-red-900/50 text-red-500 border border-red-900' :
                      vuln.severity === 'High' ? 'bg-orange-900/50 text-orange-500 border border-orange-900' :
                      vuln.severity === 'Medium' ? 'bg-yellow-900/50 text-yellow-500 border border-yellow-900' :
                      'bg-blue-900/50 text-blue-500 border border-blue-900'
                    }`}>
                      {vuln.severity}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-gray-200">{vuln.name}</td>
                  <td className="px-6 py-4 text-gray-400 font-mono text-xs">{vuln.endpoint}</td>
                  <td className="px-6 py-4 text-gray-400">{vuln.cvss}</td>
                  <td className="px-6 py-4">
                     <button 
                       onClick={() => setSelectedVuln(vuln)}
                       className="text-omega-accent hover:text-white hover:underline text-xs uppercase font-bold tracking-wide"
                     >
                       DETAILS
                     </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedVuln && (
        <VulnerabilityModal 
          vuln={selectedVuln} 
          onClose={() => setSelectedVuln(null)} 
        />
      )}
    </div>
  );
};